### The idea behind the pricing

Our pricing is organized into three simple tiers to keep the platform accessible while giving brands clear upgrade paths as their needs grow.

---

## Small and Medium (SME)

### Free (Entry)

A free, entry-level option that enables broad adoption and low operational overhead:

- Create and customize a 3D environment and publish it at no cost
- Includes a default Gether domain
- Displays "Powered by Gether" branding
- Ideal for testing, small projects, and museums or venues wanting a cost-free immersive presence

### Custom Domain & White‑Label — $50 / month

An affordable first upgrade to professionalize your presence:

- Use a custom domain
- Remove "Powered by Gether" branding (white‑label)
- Keeps hosting and management simple while presenting a branded experience
- Recommended for businesses transitioning from proof-of-concept to customer-facing operations

## Engage and Commerce Packs (Optional Upgrades)

Two modular packs add advanced functionality. They can be purchased separately or together.

- Engage Pack

  - Run webinars, masterclasses, events, and meetings inside your virtual world
  - Real-time interaction tools for attendees and hosts
  - Great for audience engagement, training, and live events

- Commerce Pack
  - Full virtual storefront for showcasing and selling products
  - Product catalogs, cart and checkout, and immersive merchandising
  - Designed for brands seeking an immersive ecommerce channel

Both packs can be combined to create a complete virtual business platform that covers most needs of small and medium-sized brands, from launch to scale.

---

## Enterprices and businesses
